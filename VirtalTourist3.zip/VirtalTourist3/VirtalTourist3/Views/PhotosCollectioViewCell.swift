//
//  CollectionViewCell.swift
//  VirtalTourist3
//
//  Created by Raghad Mah on 26/01/2019.
//  Copyright © 2019 Udacity. All rights reserved.
//

import UIKit
import Foundation

class PhotosCollectioViewCell: UICollectionViewCell {
    
    @IBOutlet var image: UIImageView!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    
}

